from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Manager, Intern

class StaffRolesView(APIView):
    def get(self, request):
        roles = []
        for mgr in Manager.objects.all():
            roles.append({'name': mgr.name, 'role': mgr.get_role()})
        for intern in Intern.objects.all():
            roles.append({'name': intern.name, 'role': intern.get_role()})
        return Response(roles)
