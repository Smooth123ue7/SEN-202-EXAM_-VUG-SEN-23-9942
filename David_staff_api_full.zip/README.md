# David Staff API

This project is a Django REST API for managing company staff, with features reflecting Object-Oriented Programming principles such as inheritance, encapsulation, and polymorphism.

## Author
**Name:** Oputa David  
**Matric Number:** 9942  
**GitHub:** [smooth123ue7](https://github.com/smooth123ue7)
